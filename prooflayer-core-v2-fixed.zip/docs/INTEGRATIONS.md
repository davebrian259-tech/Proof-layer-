# Integration status (honest, as of this commit)

| Tool | Status | Evidence that exists |
|---|---|---|
| neatlogs | Adapter implemented (`src/observability.ts`), tested against a **mock** SDK only. Real SDK not installed or connected; **no real traces exist yet.** | none |
| Entire | **Not installed or used.** The dev sandbox had no network. Commits so far were not made through an Entire-enabled agent session, so they carry **no checkpoints**. | none |
| cfo.ai | **Not started.** Requires using the product. | none |

## Enable neatlogs (per https://docs.neatlogs.com/sdk/typescript)
1. `npm install neatlogs@latest` (Node >= 18). The package is optional; ProofLayer runs without it.
2. Create a project at https://app.neatlogs.com and export its key: `export NEATLOGS_API_KEY=...`
   EU projects: also `export NEATLOGS_ENDPOINT=https://eu.ingest.neatlogs.com`.
3. Network-free check, then authenticated probe (commands from the docs):
   `npm exec --offline --no -- neatlogs doctor --local --json`
   `npm exec --offline --no -- neatlogs doctor --probe --json`
4. `npm start`, run scenarios in the dashboard, open the `prooflayer` workflow in the neatlogs dashboard.
5. `/api/health` shows `configured` once `init()` succeeds. It never claims delivery; only the probe and the neatlogs dashboard prove that.

Known limits: spans are emitted from the stored event log after a run finishes, so structure and attributes are real but per-step latency is not. The `kind` values (WORKFLOW, TOOL, GUARDRAIL, CHAIN) are from the documented span-kind list; confirm `trace()` accepts them via the probe. Only simulated data is sent.

## Use Entire in development (per https://docs.entire.io/quickstart)
Entire records sessions of a supported coding agent and links them to commits. A checkpoint exists only for commits made while an agent session is active.
1. Install: macOS `brew install --cask entireio/tap/entire`; Linux `curl -fsSL https://entire.io/install.sh | bash`. Verify with `entire version`.
2. In this repo, enable it for the agent you use, e.g. `entire enable -y --agent claude-code` (other values in the docs: codex, cursor, copilot-cli, gemini is not listed in the quickstart I read; check `entire enable --help`).
3. Work with that agent inside the repo, then `git commit`. Answer `y` (or `always`) to "Link this commit to session context?".
4. `entire checkpoint list` shows checkpoints. Data lives on branch `entire/checkpoints/v1`; the pre-push hook syncs it. Commit `.entire/settings.json` and `.entire/.gitignore`.
5. Optional web view: `entire login`, then entire.io.
Save as submission evidence: `entire checkpoint list` output and a screenshot from entire.io. I did not find `entire-graph` in the docs I read, so do not cite it unless you confirm it exists.
Suggested use: checkpoint before fixing the first real bug neatlogs reveals, then link that fix commit.

## cfo.ai
Not done. Use the product, then export or screenshot the plan; label all prices as assumptions.
