// Durable storage (node:sqlite). Keeps BOTH the initial and final verdict so the original claim stays auditable.
import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
const V = "('SUPPORTED','CONTRADICTED','UNVERIFIED')";
const ST = "('VERIFIED','FAILED','PARTIALLY_VERIFIED','NEEDS_REVIEW','IN_PROGRESS')";
const SCHEMA = `
CREATE TABLE IF NOT EXISTS task_runs(
  id TEXT PRIMARY KEY, task_description TEXT NOT NULL,
  scenario_type TEXT NOT NULL CHECK(scenario_type IN ('A','B','C','C2','D','E','F','G')),
  status TEXT NOT NULL CHECK(status IN ${ST}), initial_status TEXT NOT NULL CHECK(initial_status IN ${ST}),
  started_at TEXT NOT NULL, completed_at TEXT NOT NULL, initial_agent_response TEXT NOT NULL, final_verified_response TEXT NOT NULL,
  recovery_attempt_count INTEGER NOT NULL DEFAULT 0 CHECK(recovery_attempt_count >= 0), provider_calls INTEGER NOT NULL,
  duration_ms REAL NOT NULL, agent_mode TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS agent_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL REFERENCES task_runs(id) ON DELETE CASCADE,
  sequence_number INTEGER NOT NULL, event_type TEXT NOT NULL, tool_name TEXT, input_data TEXT, output_data TEXT,
  status TEXT NOT NULL CHECK(status IN ('completed','failed')), timestamp TEXT NOT NULL, error_details TEXT, UNIQUE(run_id, sequence_number));
CREATE TABLE IF NOT EXISTS claims(
  id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL REFERENCES task_runs(id) ON DELETE CASCADE,
  claim_ref TEXT NOT NULL, claim_text TEXT NOT NULL, claim_type TEXT NOT NULL, expected_value TEXT,
  initial_verdict TEXT NOT NULL CHECK(initial_verdict IN ${V}), initial_explanation TEXT NOT NULL,
  verdict TEXT NOT NULL CHECK(verdict IN ${V}), explanation TEXT NOT NULL, verification_rule_id TEXT NOT NULL, UNIQUE(run_id, claim_ref));
CREATE TABLE IF NOT EXISTS evidence(
  id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL REFERENCES task_runs(id) ON DELETE CASCADE,
  phase TEXT NOT NULL CHECK(phase IN ('initial','final')), evidence_ref TEXT NOT NULL, source_type TEXT NOT NULL, source_id TEXT NOT NULL,
  observed_at TEXT NOT NULL, payload TEXT NOT NULL, validation_status TEXT NOT NULL CHECK(validation_status IN ('collected','unavailable')),
  UNIQUE(run_id, phase, evidence_ref));
CREATE TABLE IF NOT EXISTS claim_evidence(
  claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE, evidence_id INTEGER NOT NULL REFERENCES evidence(id) ON DELETE CASCADE,
  relationship_type TEXT NOT NULL CHECK(relationship_type IN ('supports','contradicts','insufficient')), PRIMARY KEY(claim_id, evidence_id));
CREATE TABLE IF NOT EXISTS recovery_attempts(
  id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL REFERENCES task_runs(id) ON DELETE CASCADE,
  ordinal INTEGER NOT NULL, attempt_number INTEGER, identified_failure TEXT NOT NULL, proposed_action TEXT NOT NULL, safety_check TEXT NOT NULL,
  executed INTEGER NOT NULL CHECK(executed IN (0,1)), execution_result TEXT, verification_result TEXT, timestamp TEXT NOT NULL, UNIQUE(run_id, ordinal));
CREATE TABLE IF NOT EXISTS evaluation_results(
  id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id TEXT NOT NULL, scenario_id TEXT NOT NULL, expected_outcome TEXT NOT NULL,
  actual_outcome TEXT NOT NULL, passed INTEGER NOT NULL CHECK(passed IN (0,1)), duration REAL NOT NULL, notes TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_runs_created ON task_runs(created_at);
CREATE INDEX IF NOT EXISTS ix_events_run ON agent_events(run_id);
CREATE INDEX IF NOT EXISTS ix_claims_run ON claims(run_id);
CREATE INDEX IF NOT EXISTS ix_evidence_run ON evidence(run_id);
CREATE INDEX IF NOT EXISTS ix_recovery_run ON recovery_attempts(run_id);
CREATE INDEX IF NOT EXISTS ix_eval_batch ON evaluation_results(batch_id);`;
export function openDb(path = ':memory:') {
  const db = new DatabaseSync(path);
  db.exec('PRAGMA foreign_keys = ON;'); db.exec(SCHEMA); return db;
}
const j = (v: any) => (v === undefined ? null : JSON.stringify(v));
const p = (s: any) => (s == null ? null : JSON.parse(s));
export function saveRun(db: any, r: any, agentMode = 'scripted-demo-agent (no LLM)') {
  const id = 'run_' + randomUUID().slice(0, 8), now = new Date().toISOString();
  db.exec('BEGIN');
  try {
    db.prepare(`INSERT INTO task_runs(id,task_description,scenario_type,status,initial_status,started_at,completed_at,initial_agent_response,
      final_verified_response,recovery_attempt_count,provider_calls,duration_ms,agent_mode,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(id, r.events[0].task, r.scenario, r.final.status, r.initial.status, r.events[0].at, r.events[r.events.length - 1].at,
        r.agentMessage, r.finalMessage, r.attempts.filter((a: any) => a.executed).length, r.providerCalls, r.ms, agentMode, now);
    const ie = db.prepare('INSERT INTO agent_events(run_id,sequence_number,event_type,tool_name,input_data,output_data,status,timestamp,error_details) VALUES (?,?,?,?,?,?,?,?,?)');
    for (const e of r.events) {
      const status = e.status ?? 'completed';
      ie.run(id, e.seq, e.type, e.tool ?? null, j(e.input), j(e.output), status, e.at, status === 'failed' ? j(e.output) : null);
    }
    const ev = db.prepare('INSERT INTO evidence(run_id,phase,evidence_ref,source_type,source_id,observed_at,payload,validation_status) VALUES (?,?,?,?,?,?,?,?)');
    const evId: Record<string, number> = {};
    for (const phase of ['initial', 'final']) for (const e of r[phase].evidence)
      evId[phase + ':' + e.id] = Number(ev.run(id, phase, e.id, e.source.split(':')[0], e.source, e.observedAt, j(e.data), e.data.available === false ? 'unavailable' : 'collected').lastInsertRowid);
    const ic = db.prepare('INSERT INTO claims(run_id,claim_ref,claim_text,claim_type,expected_value,initial_verdict,initial_explanation,verdict,explanation,verification_rule_id) VALUES (?,?,?,?,?,?,?,?,?,?)');
    const il = db.prepare('INSERT OR IGNORE INTO claim_evidence(claim_id,evidence_id,relationship_type) VALUES (?,?,?)');
    for (const c of r.claims) {
      const a = r.initial.results.find((x: any) => x.claimId === c.id), f = r.final.results.find((x: any) => x.claimId === c.id);
      const cid = Number(ic.run(id, c.id, c.text, c.type, j(c.expected), a.verdict, a.explanation, f.verdict, f.explanation, f.rule).lastInsertRowid);
      for (const [phase, x] of [['initial', a], ['final', f]] as any[])
        for (const [list, rel] of [[x.supporting, 'supports'], [x.contradicting, 'contradicts'], [x.missing, 'insufficient']] as any[])
          for (const ref of list) il.run(cid, evId[phase + ':' + ref], rel);
    }
    const ia = db.prepare('INSERT INTO recovery_attempts(run_id,ordinal,attempt_number,identified_failure,proposed_action,safety_check,executed,execution_result,verification_result,timestamp) VALUES (?,?,?,?,?,?,?,?,?,?)');
    r.attempts.forEach((a: any, i: number) => ia.run(id, i + 1, a.attempt ?? null, a.failure, a.action, a.safety, a.executed ? 1 : 0, a.result ?? null, a.verificationAfter ?? null, a.at));
    db.exec('COMMIT'); return id;
  } catch (e) { db.exec('ROLLBACK'); throw e; }
}
export function getRun(db: any, id: string) {
  const run = db.prepare('SELECT * FROM task_runs WHERE id = ?').get(id);
  if (!run) return null;
  const events = db.prepare('SELECT * FROM agent_events WHERE run_id = ? ORDER BY sequence_number').all(id)
    .map((e: any) => ({ ...e, input_data: p(e.input_data), output_data: p(e.output_data), error_details: p(e.error_details) }));
  const evidence = db.prepare('SELECT * FROM evidence WHERE run_id = ? ORDER BY id').all(id).map((e: any) => ({ ...e, payload: p(e.payload) }));
  const links = db.prepare('SELECT ce.claim_id, ce.relationship_type, e.phase, e.evidence_ref FROM claim_evidence ce JOIN evidence e ON e.id = ce.evidence_id WHERE e.run_id = ?').all(id);
  const claims = db.prepare('SELECT * FROM claims WHERE run_id = ? ORDER BY id').all(id)
    .map((c: any) => ({ ...c, expected_value: p(c.expected_value), links: links.filter((l: any) => l.claim_id === c.id).map((l: any) => ({ ...l })) }));
  const recovery = db.prepare('SELECT * FROM recovery_attempts WHERE run_id = ? ORDER BY ordinal').all(id).map((a: any) => ({ ...a }));
  return { run: { ...run }, events, claims, evidence, recovery };
}
export const listRuns = (db: any, limit = 50) => db.prepare(
  'SELECT id, scenario_type, status, initial_status, recovery_attempt_count, created_at FROM task_runs ORDER BY created_at DESC, rowid DESC LIMIT ?').all(limit).map((r: any) => ({ ...r }));
export function stats(db: any) {
  const claims: any = { SUPPORTED: 0, CONTRADICTED: 0, UNVERIFIED: 0 };
  for (const r of db.prepare('SELECT verdict, COUNT(*) AS n FROM claims GROUP BY verdict').all()) claims[r.verdict] = r.n;
  return { runs: db.prepare('SELECT COUNT(*) AS n FROM task_runs').get().n, claims,
    recovered: db.prepare("SELECT COUNT(*) AS n FROM task_runs WHERE initial_status != 'VERIFIED' AND status = 'VERIFIED' AND recovery_attempt_count > 0").get().n };
}
export function saveEvaluation(db: any, batchId: string, rows: any[]) {
  const q = db.prepare('INSERT INTO evaluation_results(batch_id,scenario_id,expected_outcome,actual_outcome,passed,duration,notes,created_at) VALUES (?,?,?,?,?,?,?,?)');
  const now = new Date().toISOString();
  db.exec('BEGIN');
  try { for (const r of rows) q.run(batchId, r.scenario_id, r.expected_outcome, r.actual_outcome, r.passed ? 1 : 0, r.duration, r.notes, now); db.exec('COMMIT'); }
  catch (e) { db.exec('ROLLBACK'); throw e; }
}
export function latestEvaluation(db: any) {
  const last = db.prepare('SELECT batch_id FROM evaluation_results ORDER BY id DESC LIMIT 1').get();
  return last ? db.prepare('SELECT * FROM evaluation_results WHERE batch_id = ? ORDER BY id').all(last.batch_id).map((r: any) => ({ ...r })) : [];
}
