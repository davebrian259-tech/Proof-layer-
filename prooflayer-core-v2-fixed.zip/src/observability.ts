// neatlogs adapter (API per https://docs.neatlogs.com/sdk/typescript: init, trace, flush, shutdown, NEATLOGS_API_KEY).
// The SDK is imported dynamically, so ProofLayer runs without it. Status never claims that traces were DELIVERED.
export type TracerStatus = { state: 'disabled' | 'configured' | 'error'; detail: string; deliveryVerified: false };
const attrs = (span: any, o: Record<string, any>) => {
  for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== null) span.setAttribute('prooflayer.' + k, typeof v === 'object' ? JSON.stringify(v) : v);
};
export async function createTracer(opts: { env?: any; importer?: () => Promise<any> } = {}) {
  const env = opts.env ?? process.env, importer = opts.importer ?? (() => import('neatlogs')), key: string | undefined = env.NEATLOGS_API_KEY;
  const scrub = (m: any) => (key ? String(m).split(key).join('[redacted]') : String(m));
  let status: TracerStatus = { state: 'disabled', detail: 'NEATLOGS_API_KEY not set; tracing is off', deliveryVerified: false };
  let nl: any = null;
  if (key) {
    try { nl = await importer(); }
    catch (e: any) { status = { state: 'error', detail: `neatlogs SDK could not be loaded (${scrub(e?.code ?? e?.message)}); run: npm install neatlogs@latest`, deliveryVerified: false }; }
    if (nl) {
      try {
        await nl.init({ apiKey: key, workflowName: 'prooflayer', tags: ['prooflayer', 'neatHack'], ...(env.NEATLOGS_ENDPOINT ? { endpoint: env.NEATLOGS_ENDPOINT } : {}) });
        status = { state: 'configured', detail: 'SDK init() returned without error; delivery not verified (run neatlogs doctor --probe)', deliveryVerified: false };
      } catch (e: any) { nl = null; status = { state: 'error', detail: `neatlogs init failed: ${scrub(e?.message)}`, deliveryVerified: false }; }
    }
  }
  return {
    status: () => ({ ...status }),
    // Spans are emitted from the stored event log AFTER the run finishes: structure and attributes are real, per-step latency is not.
    async traceRun(result: any, meta: { runId: string }) {
      if (!nl) return;
      try {
        await nl.trace({ name: 'prooflayer.run', kind: 'WORKFLOW' }, async (root: any) => {
          attrs(root, { run_id: meta.runId, scenario_type: result.scenario, initial_outcome: result.initial.status, final_outcome: result.final.status,
            recovery_attempts: result.attempts.filter((a: any) => a.executed).length, verification_passed: result.final.status === 'VERIFIED', agent_mode: 'scripted-demo-agent' });
          for (const e of result.events)
            await nl.trace({ name: e.tool ?? e.type, kind: e.tool ? 'TOOL' : e.type === 'verification' ? 'GUARDRAIL' : 'CHAIN' }, async (sp: any) =>
              attrs(sp, { seq: e.seq, event_type: e.type, status: e.status ?? 'completed', output: e.output }));
          for (const r of result.final.results) {
            const first = result.initial.results.find((x: any) => x.claimId === r.claimId);
            await nl.trace({ name: 'verify:' + r.type, kind: 'GUARDRAIL' }, async (sp: any) =>
              attrs(sp, { claim_verdict: r.verdict, initial_verdict: first?.verdict, rule: r.rule, verification_passed: r.verdict === 'SUPPORTED' }));
          }
        });
        if (status.state === 'error') status = { state: 'configured', detail: 'SDK init() returned without error; delivery not verified (run neatlogs doctor --probe)', deliveryVerified: false };
      } catch (e: any) { status = { state: 'error', detail: `trace emission failed: ${scrub(e?.message)}`, deliveryVerified: false }; }
    },
    async shutdown() { if (!nl) return; try { await nl.flush(); await nl.shutdown(); } catch { /* best effort */ } },
  };
}
