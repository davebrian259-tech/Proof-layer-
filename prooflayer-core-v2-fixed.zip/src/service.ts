// Runs a scenario, persists it, optionally emits a trace. Tracing can never break a run.
import { run } from './orchestrator.ts';
import type { Scenario } from './tools.ts';
import { saveRun } from './store.ts';
export async function executeScenario(db: any, s: Scenario, tracer?: { traceRun(result: any, meta: any): Promise<void> }) {
  const result = run(s), id = saveRun(db, result);
  if (tracer) { try { await tracer.traceRun(result, { runId: id }); } catch { /* observability must not affect the run */ } }
  return { id, result };
}
