// Claim extraction, evidence collection, deterministic claim-specific rules. No LLM in the verdict path.
export type Verdict = 'SUPPORTED'|'CONTRADICTED'|'UNVERIFIED';
const TYPES = ['refund_completed','refund_amount','customer_notified'];
export function extractClaims(msg: string, orderId: string) {
  const claims: any[] = [];
  if (/has been refunded|refund (is|was|has been) (complete|processed|issued)|is complete/i.test(msg))
    claims.push({ id: 'c1', type: 'refund_completed', text: `Refund for order #${orderId} is complete`, expected: { orderId } });
  const m = msg.match(/\$(\d+(?:\.\d{2})?)/);
  if (m) claims.push({ id: 'c2', type: 'refund_amount', text: `Refund amount was $${m[1]}`, expected: { cents: Math.round(parseFloat(m[1]) * 100) } });
  if (/notified|notification (was )?sent|emailed/i.test(msg))
    claims.push({ id: 'c3', type: 'customer_notified', text: 'Customer was notified', expected: { orderId } });
  for (const c of claims) if (!c.id || !c.text || !TYPES.includes(c.type)) throw new Error('invalid claim schema');
  if (new Set(claims.map(c => c.id)).size !== claims.length) throw new Error('duplicate claim ids');
  return claims;
}
export function collectEvidence(w: any, events: any[]) {
  const at = w.now();
  const ev: any[] = [{ id: 'ev_provider', source: 'tool:payment.refund', at, data: { results: events.filter(e => e.tool === 'payment.refund').map(e => e.output) } }];
  try { ev.push({ id: 'ev_ledger', source: 'authoritative:ledger', at, data: { available: true, records: w.readLedger() } }); }
  catch (e: any) { ev.push({ id: 'ev_ledger', source: 'authoritative:ledger', at, data: { available: false, error: e.message } }); }
  ev.push({ id: 'ev_notify', source: 'authoritative:notification_log', at, data: { records: w.readNotifications() } });
  for (const e of ev) e.observedAt = new Date().toISOString();
  return ev;
}
export function verify(claims: any[], ev: any[], ctx: { orderId: string }) {
  const led = ev.find(e => e.id === 'ev_ledger').data;
  const prov = ev.find(e => e.id === 'ev_provider').data.results;
  const notes = ev.find(e => e.id === 'ev_notify').data.records.filter((n: any) => n.orderId === ctx.orderId);
  const recs = led.available ? led.records.filter((r: any) => r.orderId === ctx.orderId && r.status === 'completed') : [];
  const last = prov[prov.length - 1];
  return claims.map(c => {
    const out = (verdict: Verdict, rule: string, explanation: string, supporting: string[] = [], contradicting: string[] = [], missing: string[] = []) =>
      ({ claimId: c.id, type: c.type, verdict, rule, explanation, supporting, contradicting, missing });
    if (c.type === 'customer_notified') {
      const R = 'customer_notified_v1';
      if (notes.some((n: any) => n.status === 'delivered')) return out('SUPPORTED', R, 'Notification log shows a delivered message.', ['ev_notify']);
      if (notes.length) return out('CONTRADICTED', R, 'Notification log shows the send failed.', [], ['ev_notify']);
      return out('UNVERIFIED', R, 'No notification attempt exists in the log.', [], [], ['ev_notify']);
    }
    const R = c.type === 'refund_amount' ? 'refund_amount_v1' : 'refund_completion_v1';
    if (!led.available) return out('UNVERIFIED', R, `Authoritative ledger unavailable (${led.error}); outcome cannot be confirmed or refuted.`, [], [], ['ev_ledger']);
    if (recs.length > 1) return out('CONTRADICTED', R, 'Ledger contains duplicate completed refunds for the order.', [], ['ev_ledger']);
    if (recs.length === 1) {
      if (c.type === 'refund_completed') return out('SUPPORTED', R, 'A completed refund record for this order exists in the ledger.', ['ev_ledger']);
      return recs[0].amount === c.expected.cents
        ? out('SUPPORTED', R, 'Ledger amount matches the claimed amount.', ['ev_ledger'])
        : out('CONTRADICTED', R, `Ledger records ${recs[0].amount} cents; claim was ${c.expected.cents}.`, [], ['ev_ledger']);
    }
    if (last?.status === 'rejected') return out('CONTRADICTED', R, `Provider rejected the refund (${last.code}) and the ledger has no completed refund.`, [], ['ev_provider', 'ev_ledger']);
    return out('UNVERIFIED', R, `No completed refund in ledger; last provider status was "${last?.status ?? 'none'}", which is not conclusive.`, [], [], ['ev_ledger']);
  });
}
export function overallStatus(res: any[]) {
  const c = res.find(r => r.type === 'refund_completed')?.verdict;
  if (c === 'CONTRADICTED') return 'FAILED';
  if (c !== 'SUPPORTED') return 'NEEDS_REVIEW';
  return res.every(r => r.verdict === 'SUPPORTED') ? 'VERIFIED' : 'PARTIALLY_VERIFIED';
}
