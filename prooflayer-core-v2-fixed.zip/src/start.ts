import { mkdirSync } from 'node:fs';
import { openDb } from './store.ts';
import { createApp } from './server.ts';
import { createTracer } from './observability.ts';
mkdirSync('data', { recursive: true });
const db = openDb(process.env.PROOFLAYER_DB ?? 'data/prooflayer.db'), tracer = await createTracer();
const port = Number(process.env.PORT ?? 3000), server = createApp({ db, tracer }).listen(port, '127.0.0.1', () =>
  console.log(`ProofLayer on http://127.0.0.1:${port}  (simulated payments; scripted demo agent; neatlogs: ${tracer.status().state})`));
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, async () => { server.close(); await tracer.shutdown(); db.close(); process.exit(0); });
