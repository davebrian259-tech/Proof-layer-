// Demo agent (scripted, NOT an LLM) + bounded, safety-checked recovery + verified final report.
import { createWorld, ORDER_ID, AMOUNT } from './tools.ts';
import type { Scenario } from './tools.ts';
import { extractClaims, collectEvidence, verify, overallStatus } from './verify.ts';
const MAX_RECOVERY = 2, RECOVERABLE = new Set(['STALE_PAYMENT_REF']);
const usd = (c: number) => '$' + (c / 100).toFixed(2);
const stop = (failure: string, safety: string) => ({ failure, action: 'stop', safety });

function decide(cur: any, events: any[], n: number): any {
  const v: any = Object.fromEntries(cur.results.map((x: any) => [x.type, x.verdict]));
  const ledger = cur.evidence.find((e: any) => e.id === 'ev_ledger').data;
  const provs = events.filter(e => e.tool === 'payment.refund').map(e => e.output), last = provs[provs.length - 1];
  const notified = events.some(e => e.tool === 'notifications.send');
  if (v.refund_completed === 'SUPPORTED') {
    if (v.customer_notified !== 'SUPPORTED' && !notified && n < MAX_RECOVERY)
      return { failure: 'Customer notification never sent', action: 'send_notification', safety: 'safe_to_retry: refund verified in ledger; notification cannot move money' };
    return { action: 'none' };
  }
  if (n >= MAX_RECOVERY) return stop('Recovery budget exhausted', 'must_stop');
  if (!ledger.available) return stop('Ledger unavailable; cannot tell whether a refund exists', 'must_stop: no new refund issued');
  if (!last) return stop('No refund attempt recorded', 'must_stop');
  if (last.status === 'rejected') return RECOVERABLE.has(last.code)
    ? { failure: `Provider rejected: ${last.code} (confirmed)`, action: 'refresh_payment_ref_and_retry', safety: 'safe_to_retry: explicit rejection, ledger shows no refund, same idempotency key' }
    : stop(`Provider rejected: ${last.code}; not recoverable under policy`, 'requires_human_approval');
  if (last.status === 'timeout')
    return { failure: 'Provider timed out; ledger reconciled: no completed refund', action: 'retry_with_idempotency_key', safety: 'safe_to_retry: ledger reachable, no record, idempotency key prevents duplicates' };
  return stop(`Provider said "${last.status}" but ledger has no completed refund (source conflict)`, 'requires_human_approval');
}

export function run(s: Scenario) {
  const t0 = performance.now(), w = createWorld(s), events: any[] = [], attempts: any[] = [];
  const log = (type: string, o: any = {}) => events.push({ seq: events.length + 1, t: w.now(), at: new Date().toISOString(), type, ...o });
  const call = (tool: string, input: any, fn: () => any) => {
    const output = fn(); log('tool_call', { tool, input, output, status: ['rejected', 'timeout', 'failed'].includes(output.status) ? 'failed' : 'completed' }); return output;
  };
  const key = `refund-${ORDER_ID}-${s}`, args = { orderId: ORDER_ID, amount: AMOUNT, key };
  log('task_received', { task: `Refund order #${ORDER_ID} and confirm when complete` });
  call('orders.get', { id: ORDER_ID }, () => ({ order: w.order }));
  log('policy_check', { output: { eligible: w.order.status === 'paid' && w.order.refundableCents >= AMOUNT } });
  const r = call('payment.refund', args, () => w.refund(args));
  if (r.status === 'ok') call('notifications.send', { orderId: ORDER_ID }, () => w.notify(ORDER_ID));
  const agentMessage = `Order #${ORDER_ID} has been refunded for ${usd(AMOUNT)}. The refund is complete, and the customer has been notified.`;
  log('agent_final_message', { output: agentMessage });
  const claims = extractClaims(agentMessage, ORDER_ID);
  log('claims_extracted', { output: claims.map((c: any) => c.id) });
  const check = () => {
    const evidence = collectEvidence(w, events), results = verify(claims, evidence, { orderId: ORDER_ID });
    log('verification', { output: results.map((x: any) => [x.claimId, x.verdict]) }); return { evidence, results };
  };
  let cur = check();
  const initial = { status: overallStatus(cur.results), results: cur.results, evidence: cur.evidence }; let n = 0;
  for (;;) {
    const d = decide(cur, events, n);
    if (d.action === 'none') break;
    if (d.action === 'stop') { attempts.push({ ...d, executed: false, at: new Date().toISOString() }); log('recovery_stopped', { output: d }); break; }
    n++; log('recovery_attempt', { output: d }); let result: string;
    if (d.action === 'send_notification') result = call('notifications.send', { orderId: ORDER_ID }, () => w.notify(ORDER_ID)).status;
    else {
      if (d.action === 'refresh_payment_ref_and_retry') w.refreshPaymentRef();
      const rr = call('payment.refund', args, () => w.refund(args)); result = rr.status;
      if (rr.status === 'ok' && !events.some(e => e.tool === 'notifications.send')) call('notifications.send', { orderId: ORDER_ID }, () => w.notify(ORDER_ID));
    }
    cur = check();
    attempts.push({ attempt: n, ...d, executed: true, result, verificationAfter: overallStatus(cur.results), at: new Date().toISOString() });
  }
  const status = overallStatus(cur.results), bad = cur.results.filter((x: any) => x.verdict !== 'SUPPORTED');
  const reasons = bad.map((x: any) => `${x.type}: ${x.verdict} (${x.explanation})`).join(' ');
  const finalMessage = status === 'VERIFIED' ? `The refund of ${usd(AMOUNT)} for order #${ORDER_ID} is verified. A completed refund record exists in the payment ledger.`
    : status === 'FAILED' ? `The refund was not completed. ${reasons}`
    : status === 'NEEDS_REVIEW' ? `The refund could not be verified. ${reasons}`
    : `Partially verified. ${reasons}`;
  return { scenario: s, agentMessage, claims, initial, final: { status, results: cur.results, evidence: cur.evidence }, attempts, events, finalMessage,
    providerCalls: w.providerCalls, oracle: w.oracle, ms: performance.now() - t0 };
}
