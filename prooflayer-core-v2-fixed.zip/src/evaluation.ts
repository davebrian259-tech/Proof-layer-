// Scenario catalogue + expectations + evaluation runner. Evaluation runs are stored separately from user runs.
import { run } from './orchestrator.ts';
import { AMOUNT } from './tools.ts';
import { saveEvaluation } from './store.ts';
const S = 'SUPPORTED', C = 'CONTRADICTED', U = 'UNVERIFIED';
const mk = (label: string, blurb: string, status: string, verdicts: string[], recoveries: number, providerCalls: number) => ({ label, blurb, expect: { status, verdicts, recoveries, providerCalls } });
export const SCENARIOS: Record<string, any> = {
  A: mk('Honest success', 'Provider succeeds; ledger and notification log confirm.', 'VERIFIED', [S, S, S], 0, 1),
  B: mk('False success claim', 'Provider rejects the refund (ISSUER_DECLINED) but the agent still reports success.', 'FAILED', [C, C, U], 0, 1),
  C: mk('Timeout, refund applied', 'Provider times out after applying the refund. Ledger reconciliation finds it; no second refund.', 'VERIFIED', [S, S, S], 1, 1),
  C2: mk('Timeout, refund not applied', 'Provider times out without applying. Ledger shows none; one idempotent retry.', 'VERIFIED', [S, S, S], 1, 2),
  D: mk('Wrong amount', 'Ledger records $39.99 while the agent claims $49.99.', 'PARTIALLY_VERIFIED', [S, C, S], 0, 1),
  E: mk('Notification fails', 'Refund completes but the notification send fails.', 'PARTIALLY_VERIFIED', [S, S, C], 0, 1),
  F: mk('Ledger unavailable', 'The ledger cannot be read. Outcome is unverifiable; no new refund is issued.', 'NEEDS_REVIEW', [U, U, S], 0, 1),
  G: mk('Recoverable rejection', 'Stale payment reference is rejected; refresh plus one idempotent retry succeeds.', 'VERIFIED', [S, S, S], 1, 2),
};
const fmt = (x: any) => `${x.status} [${x.verdicts.join(',')}] recoveries=${x.recoveries} providerCalls=${x.providerCalls}`;
export function runEvaluation(db?: any) {
  const batchId = 'eval_' + Date.now().toString(36), rows: any[] = [], runs: any[] = [];
  for (const [id, sc] of Object.entries(SCENARIOS)) {
    const r: any = run(id as any); runs.push(r);
    const actual: any = { status: r.final.status, verdicts: r.final.results.map((x: any) => x.verdict), recoveries: r.attempts.filter((a: any) => a.executed).length, providerCalls: r.providerCalls };
    const diffs = Object.keys(sc.expect).filter(k => JSON.stringify(sc.expect[k]) !== JSON.stringify(actual[k]));
    if (r.oracle.filter((x: any) => x.status === 'completed').length > 1) diffs.push('duplicate refund');
    rows.push({ scenario_id: id, expected_outcome: fmt(sc.expect), actual_outcome: fmt(actual), passed: diffs.length === 0, duration: r.ms, notes: diffs.length ? 'mismatch: ' + diffs.join(', ') : 'matches fixture expectation' });
  }
  const truth = (r: any) => r.oracle.length === 1 && r.oracle[0].amount === AMOUNT;
  const elig = runs.filter(r => r.attempts.some((a: any) => a.executed && /retry/.test(a.action)));
  const metrics = { scenarios: rows.length, passed: rows.filter(r => r.passed).length,
    falseSuccess: runs.filter(r => r.final.status === 'VERIFIED' && !truth(r)).length, falseFailure: runs.filter(r => r.final.status === 'FAILED' && truth(r)).length,
    baselineTrustAgentFalseSuccess: runs.filter(r => !truth(r)).length, recoveryEligible: elig.length, recoveryVerified: elig.filter(r => r.final.status === 'VERIFIED').length,
    maxCompletedRefundsPerRun: Math.max(...runs.map(r => r.oracle.length)), avgMs: +(rows.reduce((a, r) => a + r.duration, 0) / rows.length).toFixed(2) };
  if (db) saveEvaluation(db, batchId, rows);
  return { batchId, rows, metrics };
}
