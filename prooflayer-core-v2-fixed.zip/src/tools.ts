// Simulated order system, payment provider, ledger, notifications. NO real payments.
export type Scenario = 'A'|'B'|'C'|'C2'|'D'|'E'|'F'|'G';
export const ORDER_ID = '1042';
export const AMOUNT = 4999; // cents
export function createWorld(s: Scenario) {
  let clock = 0, calls = 0, ref = s === 'G' ? 'stale' : 'fresh';
  const ledger: any[] = [], notifications: any[] = [];
  const complete = (a: any, amount: number) => {
    const r = { id: 'rf_' + (ledger.length + 1), orderId: a.orderId, amount, status: 'completed', key: a.key };
    ledger.push(r); return r;
  };
  return {
    now: () => ++clock,
    order: { id: ORDER_ID, status: 'paid', refundableCents: AMOUNT },
    get providerCalls() { return calls; },
    get oracle() { return ledger.map(r => ({ ...r })); }, // test-only ground truth
    refreshPaymentRef() { ref = 'fresh'; },
    refund(a: any) {
      calls++;
      const dup = ledger.find(r => r.key === a.key);
      if (dup) return { status: 'ok', refundId: dup.id, replay: true };
      if (s === 'B') return { status: 'rejected', code: 'ISSUER_DECLINED' };
      if (s === 'G' && ref === 'stale') return { status: 'rejected', code: 'STALE_PAYMENT_REF' };
      if (s === 'C2' && calls === 1) return { status: 'timeout' };                       // never applied
      if (s === 'C' && calls === 1) { complete(a, a.amount); return { status: 'timeout' }; } // applied, response lost
      const r = complete(a, s === 'D' ? 3999 : a.amount);
      return { status: 'ok', refundId: r.id };
    },
    notify(orderId: string) {
      const status = s === 'E' ? 'failed' : 'delivered';
      notifications.push({ orderId, status }); return { status };
    },
    readLedger() { if (s === 'F') throw new Error('ledger unavailable'); return ledger.map(r => ({ ...r })); },
    readNotifications() { return notifications.map(n => ({ ...n })); },
  };
}
