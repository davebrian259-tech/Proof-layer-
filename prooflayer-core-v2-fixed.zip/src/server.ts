// Minimal JSON API + static dashboard. Validates input server-side; never returns stack traces.
import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { executeScenario } from './service.ts';
import { getRun, listRuns, stats, latestEvaluation } from './store.ts';
import { SCENARIOS, runEvaluation } from './evaluation.ts';
const INDEX = fileURLToPath(new URL('../public/index.html', import.meta.url));
export const AGENT_MODE = 'scripted demo agent (no LLM), simulated payments';
export function createApp({ db, tracer }: { db: any; tracer?: any }) {
  const send = (res: any, code: number, body: any) => {
    const html = typeof body === 'string';
    res.writeHead(code, { 'content-type': html ? 'text/html; charset=utf-8' : 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
    res.end(html ? body : JSON.stringify(body));
  };
  const readBody = (req: any) => new Promise<any>((ok, bad) => {
    const chunks: any[] = []; let n = 0;
    req.on('data', (c: any) => { n += c.length; if (n > 4096) bad(Object.assign(new Error('body too large'), { code: 413 })); else chunks.push(c); });
    req.on('end', () => { try { ok(chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {}); } catch { bad(Object.assign(new Error('invalid JSON'), { code: 400 })); } });
    req.on('error', bad);
  });
  return createServer(async (req, res) => {
    try {
      const path = new URL(req.url ?? '/', 'http://localhost').pathname, m = req.method;
      if (m === 'GET' && path === '/') return send(res, 200, readFileSync(INDEX, 'utf8'));
      if (m === 'GET' && path === '/api/health') return send(res, 200, { ok: true, agentMode: AGENT_MODE, store: 'sqlite', neatlogs: tracer?.status() ?? { state: 'disabled', detail: 'no tracer configured' } });
      if (m === 'GET' && path === '/api/scenarios') return send(res, 200, Object.entries(SCENARIOS).map(([id, s]) => ({ id, label: s.label, blurb: s.blurb })));
      if (m === 'GET' && path === '/api/stats') return send(res, 200, stats(db));
      if (m === 'GET' && path === '/api/runs') return send(res, 200, listRuns(db));
      if (m === 'POST' && path === '/api/runs') {
        const body = await readBody(req);
        if (typeof body.scenario !== 'string' || !Object.hasOwn(SCENARIOS, body.scenario)) return send(res, 400, { error: 'unknown scenario' });
        const { id, result } = await executeScenario(db, body.scenario as any, tracer);
        return send(res, 201, { id, status: result.final.status, initial_status: result.initial.status });
      }
      const one = path.match(/^\/api\/runs\/(run_[0-9a-f]{8})$/);
      if (m === 'GET' && one) { const g = getRun(db, one[1]); return g ? send(res, 200, g) : send(res, 404, { error: 'run not found' }); }
      if (m === 'GET' && path === '/api/evaluations') return send(res, 200, { rows: latestEvaluation(db) });
      if (m === 'POST' && path === '/api/evaluations') return send(res, 201, runEvaluation(db));
      return send(res, 404, { error: 'not found' });
    } catch (e: any) {
      return send(res, [400, 413].includes(e?.code) ? e.code : 500, { error: [400, 413].includes(e?.code) ? e.message : 'internal error' });
    }
  });
}
