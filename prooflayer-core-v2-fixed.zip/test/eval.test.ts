import test from 'node:test'; import assert from 'node:assert/strict'; import { writeFileSync } from 'node:fs';
import { run } from '../src/orchestrator.ts'; import { AMOUNT } from '../src/tools.ts';
const S = 'SUPPORTED', C = 'CONTRADICTED', U = 'UNVERIFIED';
// scenario, final status, [completion, amount, notified], executed recoveries, provider calls
const T: any[] = [['A','VERIFIED',[S,S,S],0,1],['B','FAILED',[C,C,U],0,1],['C','VERIFIED',[S,S,S],1,1],['C2','VERIFIED',[S,S,S],1,2],
  ['D','PARTIALLY_VERIFIED',[S,C,S],0,1],['E','PARTIALLY_VERIFIED',[S,S,C],0,1],['F','NEEDS_REVIEW',[U,U,S],0,1],['G','VERIFIED',[S,S,S],1,2]];
const rows: any[] = [];
for (const [s, status, verdicts, rec, calls] of T) test(`scenario ${s}`, () => {
  const r = run(s);
  assert.equal(r.final.status, status); assert.deepEqual(r.final.results.map((x: any) => x.verdict), verdicts);
  assert.equal(r.attempts.filter((a: any) => a.executed).length, rec); assert.equal(r.providerCalls, calls);
  assert.ok(r.oracle.filter((x: any) => x.status === 'completed').length <= 1, 'duplicate refund');
  rows.push(r);
});
test('metrics', () => {
  const truth = (r: any) => r.oracle.length === 1 && r.oracle[0].amount === AMOUNT;
  const fs = rows.filter(r => r.final.status === 'VERIFIED' && !truth(r)).length, ff = rows.filter(r => r.final.status === 'FAILED' && truth(r)).length;
  const elig = rows.filter(r => r.attempts.some((a: any) => a.executed && /retry/.test(a.action)));
  const m = { runs: rows.length, falseSuccess: fs, falseFailure: ff, baselineTrustAgentFalseSuccess: rows.filter(r => !truth(r)).length,
    recoveryEligible: elig.length, recoveryVerified: elig.filter(r => r.final.status === 'VERIFIED').length,
    maxCompletedRefundsPerRun: Math.max(...rows.map(r => r.oracle.length)), avgMs: +(rows.reduce((a, r) => a + r.ms, 0) / rows.length).toFixed(2) };
  writeFileSync('evidence/eval-v1.json', JSON.stringify({ metrics: m, runs: rows.map(r => ({ s: r.scenario, initial: r.initial.status, final: r.final.status, attempts: r.attempts, msg: r.finalMessage })) }, null, 1));
  console.log(JSON.stringify(m)); assert.equal(fs, 0);
});
