import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { createApp } from '../src/server.ts'; import { openDb } from '../src/store.ts';
async function boot() {
  const server = createApp({ db: openDb() }); await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  const base = `http://127.0.0.1:${(server.address() as any).port}`;
  const j = async (p: string, o?: any) => { const r = await fetch(base + p, o); return { s: r.status, b: await r.json() as any }; };
  const post = (p: string, b: any) => j(p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: typeof b === 'string' ? b : JSON.stringify(b) });
  return { server, base, j, post };
}
test('health reports honest integration status; scenarios list has 8', async () => {
  const { server, j } = await boot();
  try {
    const h = await j('/api/health'); assert.equal(h.s, 200); assert.equal(h.b.neatlogs.state, 'disabled'); assert.match(h.b.agentMode, /no LLM/);
    assert.equal((await j('/api/scenarios')).b.length, 8);
    const st = await j('/api/stats'); assert.equal(st.b.runs, 0); assert.equal(st.b.claims.SUPPORTED, 0);
  } finally { server.close(); }
});
test('run B end to end via HTTP: contradicted with evidence; then list, stats', async () => {
  const { server, j, post } = await boot();
  try {
    const c = await post('/api/runs', { scenario: 'B' }); assert.equal(c.s, 201); assert.equal(c.b.status, 'FAILED');
    const g = await j('/api/runs/' + c.b.id); assert.equal(g.s, 200);
    assert.equal(g.b.claims[0].verdict, 'CONTRADICTED'); assert.ok(g.b.claims[0].links.some((l: any) => l.relationship_type === 'contradicts' && l.evidence_ref === 'ev_provider'));
    assert.ok(g.b.evidence.find((e: any) => e.evidence_ref === 'ev_provider' && e.phase === 'final').payload.results[0].code === 'ISSUER_DECLINED');
    await post('/api/runs', { scenario: 'G' });
    assert.equal((await j('/api/runs')).b.length, 2);
    const st = (await j('/api/stats')).b; assert.equal(st.runs, 2); assert.equal(st.recovered, 1); assert.ok(st.claims.CONTRADICTED >= 2);
  } finally { server.close(); }
});
test('input validation and error handling', async () => {
  const { server, j, post } = await boot();
  try {
    assert.equal((await post('/api/runs', { scenario: 'Z' })).s, 400); assert.equal((await post('/api/runs', {})).s, 400);
    assert.equal((await post('/api/runs', { scenario: '__proto__' })).s, 400); assert.equal((await post('/api/runs', '{bad')).s, 400);
    assert.equal((await post('/api/runs', { scenario: 'A', pad: 'x'.repeat(5000) })).s, 413);
    assert.equal((await j('/api/runs/run_deadbeef')).s, 404); assert.equal((await j('/api/runs/..%2f..%2fetc')).s, 404); assert.equal((await j('/nope')).s, 404);
  } finally { server.close(); }
});
test('evaluation endpoints: 8/8 pass and persisted; no run rows created', async () => {
  const { server, j, post } = await boot();
  try {
    assert.equal((await j('/api/evaluations')).b.rows.length, 0);
    const e = await post('/api/evaluations', {}); assert.equal(e.s, 201); assert.equal(e.b.metrics.passed, 8); assert.equal(e.b.metrics.falseSuccess, 0);
    assert.equal((await j('/api/evaluations')).b.rows.length, 8); assert.equal((await j('/api/stats')).b.runs, 0);
  } finally { server.close(); }
});
test('dashboard HTML is served, parses, and shows no hard-coded metrics', async () => {
  const { server, base } = await boot();
  try {
    const html = await (await fetch(base + '/')).text(); assert.match(html, /ProofLayer/);
    const src = html.match(/<script>([\s\S]*)<\/script>/)![1]; assert.doesNotThrow(() => new Function(src));
    assert.doesNotMatch(readFileSync('public/index.html', 'utf8'), /https?:\/\//, 'no external requests');
  } finally { server.close(); }
});
