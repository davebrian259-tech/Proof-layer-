// These tests use a MOCK neatlogs SDK. They prove adapter logic only; they are NOT evidence of real traces.
import test from 'node:test'; import assert from 'node:assert/strict';
import { createTracer } from '../src/observability.ts'; import { run } from '../src/orchestrator.ts'; import { executeScenario } from '../src/service.ts'; import { openDb } from '../src/store.ts';
const KEY = 'nl_secret_key_123';
function fakeSdk(o: any = {}) {
  const calls: any[] = [], spans: any[] = [];
  return { calls, spans, sdk: {
    init: async (c: any) => { calls.push(['init', c]); if (o.initFails) throw new Error('bad key ' + KEY); },
    trace: async (opt: any, fn: any) => { const a: any = {}; spans.push({ ...opt, a }); if (o.traceFails) throw new Error('network down'); return fn({ setAttribute: (k: string, v: any) => { a[k] = v; } }); },
    flush: async () => calls.push(['flush']), shutdown: async () => calls.push(['shutdown']) } };
}
test('no key: disabled, SDK never imported, traceRun is a no-op', async () => {
  let imported = false; const t = await createTracer({ env: {}, importer: async () => { imported = true; } });
  await t.traceRun(run('A'), { runId: 'r' }); assert.equal(imported, false); assert.equal(t.status().state, 'disabled'); assert.equal(t.status().deliveryVerified, false);
});
test('key but SDK missing: error status, no throw, key not leaked', async () => {
  const t = await createTracer({ env: { NEATLOGS_API_KEY: KEY }, importer: async () => { throw Object.assign(new Error('Cannot find ' + KEY), { code: 'ERR_MODULE_NOT_FOUND' }); } });
  await t.traceRun(run('A'), { runId: 'r' }); const s = t.status(); assert.equal(s.state, 'error'); assert.match(s.detail, /npm install neatlogs/); assert.ok(!JSON.stringify(s).includes(KEY));
});
test('init failure: error status, key redacted, app unaffected', async () => {
  const f = fakeSdk({ initFails: true }); const t = await createTracer({ env: { NEATLOGS_API_KEY: KEY }, importer: async () => f.sdk });
  assert.equal(t.status().state, 'error'); assert.ok(!JSON.stringify(t.status()).includes(KEY)); await t.traceRun(run('A'), { runId: 'r' }); assert.equal(f.spans.length, 0);
});
test('configured: init options, span tree and required attributes for scenario B', async () => {
  const f = fakeSdk(); const t = await createTracer({ env: { NEATLOGS_API_KEY: KEY, NEATLOGS_ENDPOINT: 'https://eu.ingest.neatlogs.com' }, importer: async () => f.sdk });
  assert.equal(t.status().state, 'configured'); assert.equal(t.status().deliveryVerified, false);
  const init = f.calls[0][1]; assert.equal(init.workflowName, 'prooflayer'); assert.equal(init.endpoint, 'https://eu.ingest.neatlogs.com');
  await t.traceRun(run('B'), { runId: 'run_abc12345' });
  const root = f.spans[0]; assert.equal(root.kind, 'WORKFLOW');
  assert.equal(root.a['prooflayer.run_id'], 'run_abc12345'); assert.equal(root.a['prooflayer.scenario_type'], 'B'); assert.equal(root.a['prooflayer.initial_outcome'], 'FAILED');
  assert.equal(root.a['prooflayer.final_outcome'], 'FAILED'); assert.equal(root.a['prooflayer.recovery_attempts'], 0); assert.equal(root.a['prooflayer.verification_passed'], false);
  assert.ok(f.spans.some(s => s.name === 'payment.refund' && s.kind === 'TOOL'));
  const v = f.spans.find(s => s.name === 'verify:refund_completed'); assert.equal(v.a['prooflayer.claim_verdict'], 'CONTRADICTED');
  assert.ok(!JSON.stringify(f.spans).includes(KEY)); await t.shutdown(); assert.deepEqual(f.calls.slice(-2).map(c => c[0]), ['flush', 'shutdown']);
});
test('scenario G trace records initial vs final verdict', async () => {
  const f = fakeSdk(); const t = await createTracer({ env: { NEATLOGS_API_KEY: KEY }, importer: async () => f.sdk }); await t.traceRun(run('G'), { runId: 'r' });
  const v = f.spans.find(s => s.name === 'verify:refund_completed'); assert.equal(v.a['prooflayer.initial_verdict'], 'CONTRADICTED'); assert.equal(v.a['prooflayer.claim_verdict'], 'SUPPORTED');
  assert.equal(f.spans[0].a['prooflayer.recovery_attempts'], 1);
});
test('tracing failure never breaks the run or its persistence', async () => {
  const f = fakeSdk({ traceFails: true }); const t = await createTracer({ env: { NEATLOGS_API_KEY: KEY }, importer: async () => f.sdk }); const db = openDb();
  const { id, result } = await executeScenario(db, 'B', t); assert.ok(id.startsWith('run_')); assert.equal(result.final.status, 'FAILED'); assert.equal(t.status().state, 'error');
});
