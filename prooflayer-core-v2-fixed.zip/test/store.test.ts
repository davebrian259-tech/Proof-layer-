import test from 'node:test'; import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs'; import { tmpdir } from 'node:os'; import { join } from 'node:path';
import { openDb, getRun, stats, latestEvaluation } from '../src/store.ts';
import { executeScenario } from '../src/service.ts';
import { runEvaluation, SCENARIOS } from '../src/evaluation.ts';

test('all eight scenarios persist with complete child rows', async () => {
  const db = openDb(); assert.equal(Object.keys(SCENARIOS).length, 8);
  for (const s of Object.keys(SCENARIOS)) {
    const { id, result } = await executeScenario(db, s as any); const g: any = getRun(db, id);
    assert.equal(g.run.status, result.final.status); assert.equal(g.events.length, result.events.length);
    assert.deepEqual(g.claims.map((c: any) => c.verdict), result.final.results.map((x: any) => x.verdict));
    assert.equal(g.recovery.length, result.attempts.length);
    assert.equal(g.run.recovery_attempt_count, result.attempts.filter((a: any) => a.executed).length);
    assert.equal(g.evidence.filter((e: any) => e.phase === 'initial').length, 3); assert.equal(g.evidence.filter((e: any) => e.phase === 'final').length, 3);
  }
  assert.equal(stats(db).runs, 8);
});
test('initial verdict and failed tool call survive recovery (scenario G audit trail)', async () => {
  const db = openDb(); const { id } = await executeScenario(db, 'G'); const g: any = getRun(db, id);
  assert.equal(g.run.initial_status, 'FAILED'); assert.equal(g.run.status, 'VERIFIED');
  assert.equal(g.claims[0].initial_verdict, 'CONTRADICTED'); assert.equal(g.claims[0].verdict, 'SUPPORTED');
  assert.equal(g.recovery[0].executed, 1); assert.equal(g.recovery[0].verification_result, 'VERIFIED');
  const failed = g.events.find((e: any) => e.tool_name === 'payment.refund' && e.status === 'failed');
  assert.equal(failed.output_data.code, 'STALE_PAYMENT_REF'); assert.ok(failed.error_details);
});
test('scenario B stores contradicting evidence links to provider and ledger', async () => {
  const db = openDb(); const { id } = await executeScenario(db, 'B'); const g: any = getRun(db, id);
  const refs = g.claims[0].links.filter((l: any) => l.phase === 'final' && l.relationship_type === 'contradicts').map((l: any) => l.evidence_ref).sort();
  assert.deepEqual(refs, ['ev_ledger', 'ev_provider']);
  assert.equal(g.run.initial_agent_response.includes('has been refunded'), true);
});
test('constraints and cascade', async () => {
  const db = openDb(); const { id } = await executeScenario(db, 'A');
  assert.throws(() => db.prepare("UPDATE claims SET verdict = 'MAYBE'").run());
  assert.throws(() => db.prepare("UPDATE task_runs SET status = 'DONE'").run());
  assert.throws(() => db.prepare("INSERT INTO agent_events(run_id,sequence_number,event_type,status,timestamp) VALUES ('nope',1,'x','completed','t')").run());
  db.prepare('DELETE FROM task_runs WHERE id = ?').run(id);
  for (const t of ['agent_events', 'claims', 'evidence', 'claim_evidence', 'recovery_attempts']) assert.equal((db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get() as any).n, 0, t);
});
test('data is durable across reopen', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pl-')), file = join(dir, 't.db');
  try {
    const a = openDb(file); const { id } = await executeScenario(a, 'D'); a.close();
    const b = openDb(file); const g: any = getRun(b, id); assert.equal(g.run.status, 'PARTIALLY_VERIFIED'); assert.equal(g.claims[1].verdict, 'CONTRADICTED'); b.close();
  } finally { rmSync(dir, { recursive: true }); }
});
test('evaluation runner: 8/8 pass, persisted, does not inflate run counts', () => {
  const db = openDb(); const r = runEvaluation(db);
  assert.equal(r.metrics.passed, 8); assert.equal(r.metrics.falseSuccess, 0); assert.equal(r.metrics.falseFailure, 0);
  assert.equal(latestEvaluation(db).length, 8); assert.equal(stats(db).runs, 0);
});
test('stats: recovered counts only runs upgraded to VERIFIED by recovery', async () => {
  const db = openDb(); for (const s of ['B', 'G', 'A']) await executeScenario(db, s as any);
  const st = stats(db); assert.equal(st.runs, 3); assert.equal(st.recovered, 1);
});
